## Purpose
This git provide useful tips to understand how to achieve 100 at 42 exams. However one should not memorize answers if not properly understood.

## Contact & contribute
To contact me and helping me to (fix bugs || improve) 42-Exam, feel free to e-mail me at **angavrel at student dot 42 dot fr**
